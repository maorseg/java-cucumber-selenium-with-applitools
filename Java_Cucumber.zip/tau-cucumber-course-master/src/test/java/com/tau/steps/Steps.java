package com.tau.steps;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Steps {

	// Initialize eyes
	private WebDriver driver;
	public static EyesRunner runner;
	private static Eyes eyes;
	public static BatchInfo batch;
	static private Boolean runAsBatch = true;

	// Initialize hook
	@Before()
	public void setup() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\maors\\Desktop\\Java_Cucumber\\chromedriver.exe");

	// To run in debug mode, enable below line:
      driver = new ChromeDriver();

	//Maximise browser window
	driver.manage().window().maximize();

	//Adding wait
	driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);

	// To run in headless mode, enable below lines:
/*	ChromeOptions options = new ChromeOptions();
	options.addArguments("--headless", "--disable-gpu");
	driver = new ChromeDriver(options);*/

	// Must be before ALL tests (at Class-level)
	batch = new BatchInfo("Your app batch");

	// Initialize the Runner for your test.
	runner = new ClassicRunner();

	// Initialize the eyes SDK
	eyes = new Eyes(runner);

	// Set your personal Applitols API Key if not set at the environment variable
	eyes.setApiKey("972J8w4Az105v43JWDbXDmcYu104105otDbmlPxk67xVsplkw4110");

	// set batch name
	eyes.setBatch(batch);

	if (runAsBatch) {

		BatchInfo batchInfo = new BatchInfo("Visual Batch");
		eyes.setBatch(batchInfo);
	}

	// Set AUT's name and test name
	eyes.open(driver, "Your App", "Visual Test");
	eyes.setForceFullPageScreenshot(true);

	}

	/// @Given ///

	@Given("I am in the home page")
	public void i_am_in_the_home_page()
	{
		driver.get("https://moodle.org");
	}


	@Given("I am in the login page")
	public void i_am_in_the_login_page()
	{
		driver.get("https://moodle.org/login/index.php");

	}

	@Given("I am in the About page")
	public void i_am_in_the_about_page()
	{
		driver.get("https://docs.moodle.org/38/en/About_Moodle");
	}

	/// @When ///

	@When("I pause shortly")
	public void i_pause_for_2_seconds() throws Exception
	{
		Thread.sleep(2000);
	}

	@When("I refresh page")
	public void i_refresh_page() throws Exception
	{
		driver.navigate().refresh();
	}

	@When("I hover on search")
	public void i_hover_on_search() throws Exception
	{
		WebElement ele = driver.findElement(By.xpath("//i[@title='Search']"));
		//Create object 'action' of an Actions class
		Actions action = new Actions(driver);
		//Mouseover on an element
		action.moveToElement(ele).perform();
	}

	@When("I type in search box")
	public void i_type_in_search_box() throws Exception
	{
		driver.findElement(By.name("q")).sendKeys("nodejs");
	}

	@When("I press Enter")
	public void i_press_Enter() throws Exception
	{
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
	}

	@When("I navigate backward")
	public void i_navigate_backward() throws Exception
	{
		driver.navigate().back();
	}

	@When("I navigate forward")
	public void i_navigate_forward() throws Exception
	{
		driver.navigate().forward();
	}

	@When("I maximize window")
	public void i_maximize_window() throws Exception
	{
		driver.manage().window().maximize();
	}

	@When("I enter invalid credentials")
	public void i_enter_invalid_credentials()
	{
		driver.findElement(By.id("username")).sendKeys("tautester");
		driver.findElement(By.id("password")).sendKeys("password");
		driver.findElement(By.id("loginbtn")).click();
	}

	@When("I enter valid credentials")
	public void i_enter_valid_credentials()
	{
		driver.findElement(By.id("username")).sendKeys("maorseg");
		driver.findElement(By.id("password")).sendKeys("q1w2e3r4!");
		driver.findElement(By.id("loginbtn")).click();
	}

	@When("I enter invalid {string} and {string}")
	public void i_enter_invalid_username_and_password(String username, String password) {
		driver.findElement(By.id("username")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.id("loginbtn")).click();

	}

	@When("I scroll down")
	public void i_scroll_down()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// Scroll the page down by 1000 pixel
		js.executeScript("window.scrollBy(0,1000)");
	}

	@When("I scroll up")
	public void i_scroll_up()
	{
		// Scroll the page back up by 1000 pixel
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-1000)");
	}

	/// @Then ///

	@Then("I should see error message")
	public void i_should_see_error_message() throws Exception
	{
		driver.findElement(By.xpath("//div[contains(text(), 'Invalid login, please try again ')]")).isDisplayed();
	}

	@Then("I should login successfully")
	public void i_should_login_successfully() throws Exception
	{
		driver.findElement(By.xpath("//span[contains(text(), 'Ma Se')]")).isDisplayed();
	}

	@Then("I take visual checkpoint")
	public void i_take_visual_checkpoint() throws Exception
	{
		eyes.checkWindow("Login page");
	}

	@Then("I should see the text")
	public void i_should_see_the_text() throws Exception
	{
		driver.findElement(By.id("yui_3_17_2_1_1588183381099_292")).isDisplayed();
	}

	@Then("I get page title")
	public void i_get_page_title() throws Exception
	{
		// Storing Title name in the String variable
		String title = driver.getTitle();
		// Printing Title & Title length in the Console window
		System.out.println("Title of the page is : " + title);
	}

	@Then("I should see the search result")
	public void i_should_see_the_search_result() throws Exception
	{
		Assert.assertEquals("Global search",driver.findElement(By.xpath("//h1[contains(.,'Global search')]")).getText());
	}

	@Then("I take screenshot")
	public void i_take_screenshot() throws Exception {
		// Take screenshot and store as a file format
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			// Copy the  screenshot to desired location using copyFile method
			FileUtils.copyFile(src, new File("C:\\Users\\maors\\Desktop\\Java_Cucumber\\screenshot.png"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	// Finish hook

	@After()
	public void quitBrowser()
	{
		// End the test.
		eyes.closeAsync();

		// If the test was aborted before eyes.close was called, ends the test as aborted.
		eyes.abortIfNotClosed();

		driver.quit();
	}

}


