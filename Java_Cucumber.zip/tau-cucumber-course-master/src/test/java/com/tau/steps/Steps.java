package com.tau.steps;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.openqa.selenium.chrome.ChromeOptions;

public class Steps {

	private WebDriver driver;
	public static EyesRunner runner;
	private static Eyes eyes;
	public static BatchInfo batch;
	static private Boolean runAsBatch = true;

	// Initialize hook
	@Before()
	public void setup() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\maors\\Desktop\\Java_Cucumber\\chromedriver.exe");

	// To run in debug mode, enable below line:
    //  driver = new ChromeDriver();

	// To run in headless mode, enable below lines:
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--headless", "--disable-gpu");
	driver = new ChromeDriver(options);

	// Must be before ALL tests (at Class-level)
	batch = new BatchInfo("the-internet.herokuapp batch");

	// Initialize the Runner for your test.
	runner = new ClassicRunner();

	// Initialize the eyes SDK
	eyes = new Eyes(runner);

	// Set your personal Applitols API Key if not set at the environment variable
	eyes.setApiKey("972J8w4Az105v43JWDbXDmcYu104105otDbmlPxk67xVsplkw4110");

	// set batch name
	eyes.setBatch(batch);

	if (runAsBatch) {

		BatchInfo batchInfo = new BatchInfo("Visual Batch");
		eyes.setBatch(batchInfo);

	}

	// Set AUT's name and test name
	eyes.open(driver, "the-internet.herokuapp App", "Visual Test");
	eyes.setForceFullPageScreenshot(true);

	}

	/// @Given ///

	@Given("I am in the login page of herokuapp")
	public void i_am_in_the_login_page_of_herokuapp()
	{
		driver.get("https://the-internet.herokuapp.com/login");

	}

	@Given("I am in the registration page of alohasystemtest")
	public void i_am_in_the_registration_page_of_herokuapp()
	{
		driver.get("");
	}

	/// @When ///

	@When("I pause shortly")
	public void i_pause_for_2_seconds() throws Exception
	{
		Thread.sleep(2000);
	}

	@When("I refresh page")
	public void i_refresh_page() throws Exception
	{
		driver.navigate().refresh();
	}

	@When("I maximize window")
	public void i_maximize_window() throws Exception
	{
		driver.manage().window().maximize();
	}

	@When("I enter invalid credentials")
	public void i_enter_invalid_credentials()
	{
		driver.findElement(By.id("username")).sendKeys("tautester");
		driver.findElement(By.id("password")).sendKeys("password");
		driver.findElement(By.xpath("//i[contains(.,' Login')]")).click();
	}

	@When("I enter valid credentials")
	public void i_enter_valid_credentials()
	{
		driver.findElement(By.id("username")).sendKeys("tomsmith");
		driver.findElement(By.id("password")).sendKeys("SuperSecretPassword!");
		driver.findElement(By.xpath("//i[contains(.,' Login')]")).click();
	}

	@When("I enter invalid {string} and {string}")
	public void i_enter_invalid_username_and_password(String username, String password) {

		driver.findElement(By.id("username")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.xpath("//i[contains(.,' Login')]")).click();

	}

	/// @Then ///

	@Then("I should see error message")
	public void i_should_see_error_message() throws Exception
	{
		driver.findElement(By.xpath("//div[@id='flash-messages']/div[contains(.,' Your username is invalid!')]")).isDisplayed();
	}

	@Then("I should see login successful message")
	public void i_should_see_login_successful_message() throws Exception
	{
		driver.findElement(By.xpath("//div[@id='flash-messages']/div[contains(.,'You logged into a secure area!')]")).isDisplayed();
	}

	@Then("I take visual checkpoint")
	public void i_take_visual_checkpoint() throws Exception
	{
		eyes.checkWindow("Login page");
	}

	// Finish hook

	@After()
	public void quitBrowser()
	{
		// End the test.
		eyes.closeAsync();

		// If the test was aborted before eyes.close was called, ends the test as aborted.
		eyes.abortIfNotClosed();

		driver.quit();
	}
}


