package com.tau.steps;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.EyesRunner;
import com.applitools.eyes.selenium.ClassicRunner;
import com.applitools.eyes.selenium.Eyes;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Steps {

	private WebDriver driver;
	public static EyesRunner runner;
	private static Eyes eyes;
	public static BatchInfo batch;
	static private Boolean runAsBatch = true;

	@Before()
	public void setup() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\maors\\Desktop\\Java_Cucumber\\chromedriver.exe");

	// Initialize the Chrome browser
	driver = new ChromeDriver();

	// Must be before ALL tests (at Class-level)
	batch = new BatchInfo("alohasystemtest batch");

	// Initialize the Runner for your test.
	runner = new ClassicRunner();

	// Initialize the eyes SDK
	eyes = new Eyes(runner);

	// Set your personal Applitols API Key if not set at the environment variable
	eyes.setApiKey("972J8w4Az105v43JWDbXDmcYu104105otDbmlPxk67xVsplkw4110");

	// set batch name
	eyes.setBatch(batch);

	if (runAsBatch) {

		BatchInfo batchInfo = new BatchInfo("Visual Batch");
		eyes.setBatch(batchInfo);

	}

	// Set AUT's name and test name
	eyes.open(driver, "alohasystemtest App", "Visual Test");
	eyes.setForceFullPageScreenshot(true);

	}

	@Given("I am in the login page of alohasystemtest")
	public void i_am_in_the_login_page_of_alohasystemtest()
	{
		driver.get("https://alohasystemtest.online/login");

	}

	@Given("I am in the registration page of alohasystemtest")
	public void i_am_in_the_registration_page_of_alohasystemtest()
	{
		driver.get("https://alohasystemtest.online/register");
	}

	@When("I pause shortly")
	public void i_pause_for_2_seconds() throws Exception
	{
		Thread.sleep(2000);
	}

	@When("I enter invalid credentials")
	public void i_enter_invalid_credentials()
	{
		driver.findElement(By.id("email")).sendKeys("tautester");
		driver.findElement(By.id("password")).sendKeys("password");
		driver.findElement(By.xpath("//button[text()='Login']")).click();
	}

	@When("I enter invalid {string} and {string}")
	public void i_enter_invalid_username_and_password(String username, String password) {

		driver.findElement(By.id("email")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.xpath("//button[text()='Login']")).click();

	}

	@Then("I should see error message")
	public void i_should_see_error_message() throws Exception
	{
		driver.findElement(By.xpath("//span[text()=' One or more of the login details are wrong ']")).isDisplayed();
	}

	@Then("I take visual checkpoint")
	public void i_take_visual_checkpoint() throws Exception
	{
		eyes.checkWindow("Login page");
	}

	@After()
	public void quitBrowser()
	{
		// End the test.
		eyes.closeAsync();

		// If the test was aborted before eyes.close was called, ends the test as aborted.
		eyes.abortIfNotClosed();

		driver.quit();
	}
}


