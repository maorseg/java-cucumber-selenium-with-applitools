package com.salad.enums;

public enum SelectorType{
    CSS,
    XPATH,
    CLASS,
    NAME,
    LINK,
    TEXT
}
